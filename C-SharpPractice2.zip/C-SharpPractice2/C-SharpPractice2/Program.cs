﻿using System;
class MakeChange
{
    static void Main()
    {
        Console.Write("Enter the amount in dollars: ");
        int dollars = int.Parse(Console.ReadLine());

        int twenties = dollars / 20;
        dollars = dollars % 20;
        int tens = dollars / 10;
        dollars = tens % 10;
        int fives = dollars / 5;
        dollars = fives % 5;
        int ones = dollars / 1;

        Console.WriteLine("twenties: {0} tens: {1} fives: {2} ones: {3}", twenties, tens, fives, ones);
    }
}