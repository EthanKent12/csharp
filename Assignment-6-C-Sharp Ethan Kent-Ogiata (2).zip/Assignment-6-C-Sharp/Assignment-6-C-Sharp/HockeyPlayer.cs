﻿public class HockeyPlayer
{
    // Attributes
    private readonly string _name;
    private int _jerseyNumber;
    private int _goalsScored;

    // Constructor
    public HockeyPlayer(string name, int jerseyNumber, int goalsScored)
    {
        _name = name;
        _jerseyNumber = jerseyNumber;
        _goalsScored = goalsScored;
    }

    // Properties
    public string Name
    {
        get { return _name; }
    }

    public int JerseyNumber
    {
        get { return _jerseyNumber; }
        set { _jerseyNumber = value; }
    }

    public int GoalsScored
    {
        get { return _goalsScored; }
        set { _goalsScored = value; }
    }
}
