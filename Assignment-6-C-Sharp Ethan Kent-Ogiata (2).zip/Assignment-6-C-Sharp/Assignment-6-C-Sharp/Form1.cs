﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_6_C_Sharp
{
    public partial class Form1 : Form
    {
        private HockeyPlayer[] players;
        private int playerCount;
        public Form1()
        {
            InitializeComponent();
            players = new HockeyPlayer[30];
            playerCount = 0;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            /** I accidentally double clicked this. 
             * It has nothing to do with the code
             */
        }

        private void AddPlayerBtn_Click(object sender, EventArgs e)
        {
            string playerName = playerNameTB.Text;
            int jerseyNumber = int.Parse(jerseyNumberTB.Text);
            int goalsScored = int.Parse(numberOfGoalsTB.Text);

            HockeyPlayer newPlayer = new HockeyPlayer(playerName, jerseyNumber, goalsScored);

            players[playerCount] = newPlayer;
            playerCount++;

            playerNameTB.Clear();
            jerseyNumberTB.Clear();
            numberOfGoalsTB.Clear();
        }

        private void displayPlayerBtn_Click(object sender, EventArgs e)
        {
            playersRTB.Clear();
            playersRTB.AppendText("Player Name\t   Jersey Number\t   Goals Scored\n");

            for (int i = 0; i < playerCount; i++)
            {
                HockeyPlayer currentPlayer = players[i];
                playersRTB.AppendText($"{currentPlayer.Name}\t {currentPlayer.JerseyNumber, -6}\t {currentPlayer.GoalsScored, -7}\n");
            }
        }

        private void playersRTB_TextChanged(object sender, EventArgs e)
        {
            /** I accidentally double clicked this. 
             * It has nothing to do with the code it is only a variable to be used in displayPlayerBtn_Click
             */

        }
    }
}
