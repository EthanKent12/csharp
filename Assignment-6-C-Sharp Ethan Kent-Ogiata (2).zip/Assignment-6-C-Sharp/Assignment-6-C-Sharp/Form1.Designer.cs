﻿namespace Assignment_6_C_Sharp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.playerNameTB = new System.Windows.Forms.TextBox();
            this.jerseyNumberTB = new System.Windows.Forms.TextBox();
            this.numberOfGoalsTB = new System.Windows.Forms.TextBox();
            this.AddPlayerBtn = new System.Windows.Forms.Button();
            this.displayPlayerBtn = new System.Windows.Forms.Button();
            this.playersRTB = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(135, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Player\'s Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(349, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Jersey Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(569, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Number Of Goals Scored";
            // 
            // playerNameTB
            // 
            this.playerNameTB.Location = new System.Drawing.Point(123, 81);
            this.playerNameTB.Name = "playerNameTB";
            this.playerNameTB.Size = new System.Drawing.Size(100, 20);
            this.playerNameTB.TabIndex = 3;
            // 
            // jerseyNumberTB
            // 
            this.jerseyNumberTB.Location = new System.Drawing.Point(335, 81);
            this.jerseyNumberTB.Name = "jerseyNumberTB";
            this.jerseyNumberTB.Size = new System.Drawing.Size(100, 20);
            this.jerseyNumberTB.TabIndex = 4;
            // 
            // numberOfGoalsTB
            // 
            this.numberOfGoalsTB.Location = new System.Drawing.Point(577, 81);
            this.numberOfGoalsTB.Name = "numberOfGoalsTB";
            this.numberOfGoalsTB.Size = new System.Drawing.Size(100, 20);
            this.numberOfGoalsTB.TabIndex = 5;
            // 
            // AddPlayerBtn
            // 
            this.AddPlayerBtn.Location = new System.Drawing.Point(247, 164);
            this.AddPlayerBtn.Name = "AddPlayerBtn";
            this.AddPlayerBtn.Size = new System.Drawing.Size(75, 23);
            this.AddPlayerBtn.TabIndex = 6;
            this.AddPlayerBtn.Text = "Add Player";
            this.AddPlayerBtn.UseVisualStyleBackColor = true;
            this.AddPlayerBtn.Click += new System.EventHandler(this.AddPlayerBtn_Click);
            // 
            // displayPlayerBtn
            // 
            this.displayPlayerBtn.Location = new System.Drawing.Point(468, 164);
            this.displayPlayerBtn.Name = "displayPlayerBtn";
            this.displayPlayerBtn.Size = new System.Drawing.Size(104, 23);
            this.displayPlayerBtn.TabIndex = 7;
            this.displayPlayerBtn.Text = "Display Player";
            this.displayPlayerBtn.UseVisualStyleBackColor = true;
            this.displayPlayerBtn.Click += new System.EventHandler(this.displayPlayerBtn_Click);
            // 
            // playersRTB
            // 
            this.playersRTB.Location = new System.Drawing.Point(196, 226);
            this.playersRTB.Name = "playersRTB";
            this.playersRTB.Size = new System.Drawing.Size(417, 96);
            this.playersRTB.TabIndex = 8;
            this.playersRTB.Text = "";
            this.playersRTB.TextChanged += new System.EventHandler(this.playersRTB_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.playersRTB);
            this.Controls.Add(this.displayPlayerBtn);
            this.Controls.Add(this.AddPlayerBtn);
            this.Controls.Add(this.numberOfGoalsTB);
            this.Controls.Add(this.jerseyNumberTB);
            this.Controls.Add(this.playerNameTB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox playerNameTB;
        private System.Windows.Forms.TextBox jerseyNumberTB;
        private System.Windows.Forms.TextBox numberOfGoalsTB;
        private System.Windows.Forms.Button AddPlayerBtn;
        private System.Windows.Forms.Button displayPlayerBtn;
        private System.Windows.Forms.RichTextBox playersRTB;
    }
}

