﻿using System;
class MoveEstimator
{
    static void Main()
    {
        const double BASE_RATE = 200;
        const double HOURLY_RATE = 150;
        const double MILE_RATE = 2;
        Console.Write("Enter the estimated number of hours: "); 
        double hours = double.Parse(Console.ReadLine());

        Console.Write("Enter the estimated number of miles for the move: ");
        double miles = double.Parse(Console.ReadLine());

        double totalFee = BASE_RATE + (HOURLY_RATE * hours) + (MILE_RATE * miles);

        Console.WriteLine("The total moving fee is: " + totalFee.ToString("C"));
    }
}