using static System.Console;
class DisplaySomeMoney
{
   static void Main()
   {
      double someMoney = 39.45;
      WriteLine(someMoney);
   }
}
