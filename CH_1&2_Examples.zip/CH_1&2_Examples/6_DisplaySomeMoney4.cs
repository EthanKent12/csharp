using static System.Console;
class DisplaySomeMoney4
{
   static void Main()
   {
      double someMoney = 39.45;
      WriteLine("I have ${0}. ${0}!! ${0}!!", someMoney);
   }
}
