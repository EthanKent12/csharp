using static System.Console;
class DisplayForFigure13
{
   static void Main()
   {
      int x = 4;
      double y = 5;
      int z = x * y;
   }
}

