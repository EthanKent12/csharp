﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assign5
{
    public partial class Form1 : Form
    {
        private string[] areaCode = {"236", "250", "778", "507", "780", "805", "403",
                                     "587", "825", "306", "639", "204", "432", "807",
                                     "249", "705", "226", "519", "548", "709"};
        private double[] rate = { .05, .05, .05, .03, .03, .03, .04, .06, .06, .06,
                                  .08, .08, .08, .09, .09, .09, .10, .10, .12, .14};

        private int[] minTime = { 3, 3, 3, 0, 0, 0, 5, 5, 5, 2,
                                  2, 2, 4, 4, 4, 6, 6, 6, 8, 9};

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Shutdown the painting of the comboBox as items are added.
            comboBox1.BeginUpdate();


            //load comboBox with the area codes
            //use the method comboBox1.Items.Add("403");
            foreach (string code in areaCode)
            {
                comboBox1.Items.Add(code);
            }

            // Allow the comboBox to repaint and display the new items.
            comboBox1.EndUpdate();
        }


        // comboBox was changed - calculate the charges for the phone call
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedIndex = comboBox1.SelectedIndex;
            // calling rate and minimum time from private arrays
            double selectedRate = rate[selectedIndex]; // calling from private rate array
            int selectedMinTime = minTime[selectedIndex]; // calling from minimum call time array
            // to display the rate and minimum call time in their respective lables.
            rateBox.Text = selectedRate.ToString("C2");
            minBox.Text = selectedMinTime.ToString();
            // to calculate call charge
            if (!string.IsNullOrEmpty(lengthBox.Text))
            {
                int callDuration = int.Parse(lengthBox.Text);
                double callCharge = selectedRate * callDuration;
                totalBox.Text = callCharge.ToString("C2");
            }
            else
            {
                totalBox.Text = "";
            }

        }

        private void lengthBox_TextChanged(object sender, EventArgs e)
        {
            comboBox1_SelectedIndexChanged(sender, e);
        }
    }
}
